#include <stdio.h>

void swap(/*???*/);
void printarray(/*???*/);